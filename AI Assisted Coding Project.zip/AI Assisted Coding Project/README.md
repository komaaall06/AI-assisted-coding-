# CodeMate AI — AI Assisted Coding System (Machine Learning)

A website that works like a lightweight, self-hosted "Copilot": type a coding
query (e.g. `binary search`, `merge sort`, `for loop`), pick a language, and
a trained TF-IDF + Multinomial Naive Bayes model matches it to the closest
snippet and instantly shows you the **code**, a **plain-English explanation**,
and its **time/space complexity**.

## 🛠 Tech Stack
- **Frontend:** HTML5, CSS3, JavaScript
- **Backend:** Python, Flask
- **Machine Learning:** scikit-learn (TF-IDF Vectorizer + Multinomial Naive Bayes)
- **Database:** SQLite

## 🚀 Setup & Run

```bash
# 1. Create a virtual environment (recommended)
python -m venv venv
source venv/bin/activate      # Windows: venv\Scripts\activate

# 2. Install dependencies
pip install -r requirements.txt

# 3. Train the ML model (creates model/model.pkl and model/vectorizer.pkl)
python train_model.py

# 4. Run the Flask app
python app.py
```

Then open **http://127.0.0.1:5000** in your browser.

## 📂 Project Structure

```
AI-Assisted-Coding-System/
├── app.py                 # Main Flask application (all routes)
├── train_model.py         # Trains the TF-IDF + Naive Bayes model
├── requirements.txt
├── README.md
├── dataset/
│   └── coding_dataset.csv # Training data (query, language, code, explanation, complexity)
├── model/
│   ├── model.pkl          # Generated after running train_model.py
│   └── vectorizer.pkl     # Generated after running train_model.py
├── templates/
│   ├── base.html
│   ├── index.html
│   ├── result.html
│   ├── login.html
│   ├── register.html
│   ├── history.html
│   └── about.html
├── static/
│   ├── css/style.css
│   ├── js/script.js
│   └── images/
├── utils/
│   ├── predict.py         # Loads model, runs predictions
│   └── database.py        # SQLite helper functions
└── database/
    └── coding.db           # Created automatically on first run
```

## 🤖 How the ML Matching Works

```
User enters query
        ↓
Text cleaning (lowercase, strip punctuation)
        ↓
TF-IDF Vectorizer → numeric features
        ↓
Multinomial Naive Bayes → predicts closest category
        ↓
Fetch matching row from dataset (filtered by language if selected)
        ↓
Display code, explanation, time & space complexity
        ↓
Save the search to history (DB if logged in, session if guest)
```

## ➕ Adding More Snippets

Just add rows to `dataset/coding_dataset.csv` (same columns:
`category,query,language,code,explanation,time_complexity,space_complexity`)
and re-run `python train_model.py`. No code changes needed — the model
retrains automatically on the updated data.

## 🔐 Notes on the Demo Auth System

Passwords are hashed with Werkzeug's `generate_password_hash` /
`check_password_hash` — never stored in plain text. For a real production
deployment, swap `app.secret_key` in `app.py` for a securely generated
secret pulled from an environment variable, and consider adding rate
limiting / CSRF protection.
