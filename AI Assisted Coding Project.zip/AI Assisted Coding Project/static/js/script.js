// script.js
// Small client-side enhancements for CodeMate AI

document.addEventListener("DOMContentLoaded", () => {
    // Auto-dismiss flash messages after a few seconds
    const flashes = document.querySelectorAll(".flash-message");
    flashes.forEach((el) => {
        setTimeout(() => {
            el.style.transition = "opacity 0.5s ease";
            el.style.opacity = "0";
            setTimeout(() => el.remove(), 500);
        }, 4000);
    });

    // Focus the search bar automatically on the home page
    const searchBar = document.querySelector(".search-bar");
    if (searchBar) {
        searchBar.focus();
    }
});

/**
 * Optional: live "as-you-type" suggestion helper.
 * Calls the /api/predict endpoint (Copilot-style live preview).
 * Not wired into the UI by default — hook this up to an <input>
 * "input" event if you want a live preview panel on the home page.
 */
async function getLiveSuggestion(query, language) {
    if (!query || query.length < 3) return null;
    try {
        const res = await fetch("/api/predict", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ query, language }),
        });
        return await res.json();
    } catch (err) {
        console.error("Prediction request failed:", err);
        return null;
    }
}
