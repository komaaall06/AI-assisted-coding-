"""
app.py
------
Main Flask application for the AI-Assisted Coding System.

Flow (matches spec):
    User -> Flask -> Load ML Model -> Predict Query -> Read Dataset
          -> Display Code -> Save Search History
"""

import os
from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify

from utils import database as db
from utils import predict as ml

app = Flask(__name__)
app.secret_key = "change-this-secret-key-in-production"  # used for session cookies

# Make sure the SQLite database + tables exist on startup
db.init_db()


def current_user():
    if "user_id" in session:
        return db.get_user_by_id(session["user_id"])
    return None


@app.context_processor
def inject_user():
    return {"user": current_user()}


# ---------------------------------------------------------------------
# Home page
# ---------------------------------------------------------------------
@app.route("/")
def index():
    languages = ml.get_available_languages()

    recent_searches = []
    user = current_user()
    if user:
        recent_searches = db.get_history(user["id"], limit=5)
    else:
        recent_searches = session.get("guest_history", [])[-5:][::-1]

    return render_template("index.html", languages=languages, recent_searches=recent_searches)


# ---------------------------------------------------------------------
# Search -> ML Prediction -> Result page
# ---------------------------------------------------------------------
@app.route("/search", methods=["POST"])
def search():
    query = request.form.get("query", "").strip()
    language = request.form.get("language", "").strip()

    if not query:
        flash("Please enter a coding query to search.")
        return redirect(url_for("index"))

    result = ml.predict_code(query, language if language else None)

    # Save to history (DB if logged in, session if guest)
    user = current_user()
    if user:
        db.add_search(user["id"], query, language)
    else:
        guest_history = session.get("guest_history", [])
        guest_history.append({"query": query, "language": language})
        session["guest_history"] = guest_history[-20:]

    if result is None:
        flash("No matching code snippet found. Try a different query.")
        return redirect(url_for("index"))

    return render_template("result.html", user_query=query, result=result)


# API endpoint if you want live "as you type" suggestions (like Copilot)
@app.route("/api/predict", methods=["POST"])
def api_predict():
    data = request.get_json(force=True)
    query = data.get("query", "")
    language = data.get("language")
    result = ml.predict_code(query, language)
    return jsonify(result or {})


# ---------------------------------------------------------------------
# Auth
# ---------------------------------------------------------------------
@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")

        if not name or not email or not password:
            flash("All fields are required.")
            return redirect(url_for("register"))

        created = db.create_user(name, email, password)
        if not created:
            flash("An account with that email already exists.")
            return redirect(url_for("register"))

        flash("Account created successfully. Please log in.")
        return redirect(url_for("login"))

    return render_template("register.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")

        user = db.verify_user(email, password)
        if user:
            session["user_id"] = user["id"]
            flash(f"Welcome back, {user['name']}!")
            return redirect(url_for("index"))

        flash("Invalid email or password.")
        return redirect(url_for("login"))

    return render_template("login.html")


@app.route("/logout")
def logout():
    session.pop("user_id", None)
    flash("You have been logged out.")
    return redirect(url_for("index"))


# ---------------------------------------------------------------------
# History / About
# ---------------------------------------------------------------------
@app.route("/history")
def history():
    user = current_user()
    if not user:
        flash("Please log in to view your search history.")
        return redirect(url_for("login"))

    records = db.get_history(user["id"], limit=50)
    return render_template("history.html", records=records)


@app.route("/about")
def about():
    return render_template("about.html")


if __name__ == "__main__":
    app.run(debug=True)
