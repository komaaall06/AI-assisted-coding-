"""
train_model.py
----------------
Trains a TF-IDF Vectorizer + Multinomial Naive Bayes classifier on the
coding_dataset.csv file. The model learns to map a free-text coding query
(e.g. "how to search sorted array", "loop in python") to the closest
known query CATEGORY (e.g. "binary_search", "for_loop") in the dataset.

Run this once before starting the Flask app:
    python train_model.py
"""

import re
import string
import pandas as pd
import joblib
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB

DATASET_PATH = "dataset/coding_dataset.csv"
MODEL_PATH = "model/model.pkl"
VECTORIZER_PATH = "model/vectorizer.pkl"


def clean_text(text: str) -> str:
    """Lowercase, strip punctuation/extra whitespace from a query string."""
    text = str(text).lower()
    text = re.sub(f"[{re.escape(string.punctuation)}]", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text


def train():
    print("Loading dataset...")
    df = pd.read_csv(DATASET_PATH)

    # Some categories have several rows (one per language) -> that's fine,
    # it gives Naive Bayes more examples per category and improves matching.
    df["clean_query"] = df["query"].apply(clean_text)

    X_text = df["clean_query"]
    y = df["category"]

    print(f"Training on {len(df)} rows across {y.nunique()} categories...")

    vectorizer = TfidfVectorizer(ngram_range=(1, 2), stop_words="english", sublinear_tf=True)
    X = vectorizer.fit_transform(X_text)

    model = MultinomialNB(alpha=0.3)
    model.fit(X, y)

    joblib.dump(model, MODEL_PATH)
    joblib.dump(vectorizer, VECTORIZER_PATH)

    print(f"Model saved to {MODEL_PATH}")
    print(f"Vectorizer saved to {VECTORIZER_PATH}")
    print("Training complete.")


if __name__ == "__main__":
    train()
