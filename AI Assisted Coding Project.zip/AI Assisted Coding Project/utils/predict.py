"""
utils/predict.py
-----------------
Loads the trained TF-IDF vectorizer + Naive Bayes model and exposes a
single function, predict_code(), that mimics an "autocomplete" style
AI coding assistant:

    user query + language  --->  closest matching code snippet
"""

import os
import re
import string
import pandas as pd
import joblib

BASE_DIR = os.path.dirname(os.path.dirname(__file__))
MODEL_PATH = os.path.join(BASE_DIR, "model", "model.pkl")
VECTORIZER_PATH = os.path.join(BASE_DIR, "model", "vectorizer.pkl")
DATASET_PATH = os.path.join(BASE_DIR, "dataset", "coding_dataset.csv")

_model = None
_vectorizer = None
_dataset = None


def _load():
    """Lazy-load the model, vectorizer, and dataset (only once)."""
    global _model, _vectorizer, _dataset
    if _model is None:
        _model = joblib.load(MODEL_PATH)
    if _vectorizer is None:
        _vectorizer = joblib.load(VECTORIZER_PATH)
    if _dataset is None:
        _dataset = pd.read_csv(DATASET_PATH)
    return _model, _vectorizer, _dataset


def clean_text(text: str) -> str:
    text = str(text).lower()
    text = re.sub(f"[{re.escape(string.punctuation)}]", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text


def predict_code(user_query: str, language: str = None):
    """
    Predicts the closest matching code snippet for a free-text query.

    Steps (matches the spec's ML workflow):
        1. Clean the input text
        2. Vectorize with TF-IDF
        3. Predict the closest category with Naive Bayes
        4. Fetch the matching row from the dataset (respecting language
           if the user picked one, otherwise best available match)

    Returns a dict with query, language, code, explanation, time, space
    or None if nothing could be predicted (empty dataset/model missing).
    """
    model, vectorizer, dataset = _load()

    cleaned = clean_text(user_query)
    if not cleaned:
        return None

    X = vectorizer.transform([cleaned])
    predicted_category = model.predict(X)[0]

    # Confidence score (how sure the model is) - nice to surface in UI
    proba = model.predict_proba(X)[0]
    confidence = round(max(proba) * 100, 2)

    matches = dataset[dataset["category"] == predicted_category]

    if language:
        lang_matches = matches[matches["language"].str.lower() == language.lower()]
        if not lang_matches.empty:
            matches = lang_matches
        # else: fall back to any available language for that category

    if matches.empty:
        return None

    row = matches.iloc[0]

    return {
        "matched_query": row["query"],
        "language": row["language"],
        "code": row["code"],
        "explanation": row["explanation"],
        "time_complexity": row["time_complexity"],
        "space_complexity": row["space_complexity"],
        "confidence": confidence,
    }


def get_available_languages():
    _, _, dataset = _load()
    return sorted(dataset["language"].unique().tolist())
